//
//  AipOcrSdk.h
//  AipOcrSdk
//
//  Created by chenxiaoyu on 17/2/7.
//  Copyright © 2017年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AipOcrSdk.
FOUNDATION_EXPORT double AipOcrSdkVersionNumber;

//! Project version string for AipOcrSdk.
FOUNDATION_EXPORT const unsigned char AipOcrSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AipOcrSdk/PublicHeader.h>

#import <AipOcrSdk/AipGeneralVC.h>
#import <AipOcrSdk/AipCaptureCardVC.h>
#import <AipOcrSdk/AipOcrService.h>



