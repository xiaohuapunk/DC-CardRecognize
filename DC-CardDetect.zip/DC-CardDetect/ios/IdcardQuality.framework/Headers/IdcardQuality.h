//
//  IdcardQuality.h
//  IdcardQuality
//
//  Created by Yan,Xiangda on 2017/4/17.
//  Copyright © 2017年 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IdcardQuality.
FOUNDATION_EXPORT double IdcardQualityVersionNumber;

//! Project version string for IdcardQuality.
FOUNDATION_EXPORT const unsigned char IdcardQualityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdcardQuality/PublicHeader.h>

#import <IdcardQuality/IdcardQualityAdaptor.h>
#import <IdcardQuality/idcard_quality.h>
